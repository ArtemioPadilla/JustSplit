# @cyber-eco/types

TypeScript interfaces and constants for the CyberEco ecosystem. This package contains **zero runtime dependencies** — types, interfaces, and constants only.

## Installation

```bash
npm install @cyber-eco/types
# or
pnpm add @cyber-eco/types
```

## Overview

This package provides:

- **Data models** for users, groups, transactions, activities, and notifications
- **Orchestration interfaces** for storage adapters, caching, sync, and webhooks
- **Permission system** with 4-tier role hierarchy
- **Query interfaces** for database operations
- **Navigation configs** for website, hub, and apps
- **Constants** for breakpoints, collections, and roles
- **App-specific types** namespaced (e.g., JustSplit)

## Usage

### Core Data Types

```typescript
import type {
  HubUser,
  SharedUserProfile,
  SharedGroup,
  Transaction,
  Notification,
} from '@cyber-eco/types';

// User with Hub-specific fields
const user: HubUser = {
  id: 'user123',
  name: 'John Doe',
  email: 'john@example.com',
  apps: ['justsplit', 'somos'],
  permissions: [],
  preferences: {
    theme: 'system', // 'light' | 'dark' | 'system'
    language: 'en',
    notifications: true,
  },
};

// Shared transaction across financial apps
const transaction: Transaction = {
  id: 'tx123',
  userId: 'user123',
  type: 'expense',
  amount: 50.0,
  currency: 'USD',
  description: 'Dinner',
  date: '2025-01-15',
  appId: 'justsplit',
  createdAt: '2025-01-15T18:30:00Z',
};
```

### Permission System (4-tier)

```typescript
import type { AppRole, GroupMember } from '@cyber-eco/types';
import { ROLE_HIERARCHY, hasMinimumRole } from '@cyber-eco/types';

// 4-tier role: 'owner' | 'admin' | 'moderator' | 'member'
const member: GroupMember = {
  userId: 'user123',
  role: 'moderator',
  joinedAt: '2025-01-01',
};

// Check role hierarchy
if (hasMinimumRole('admin', 'moderator')) {
  console.log('Admin has at least moderator privileges');
}

// Role values: owner=4, admin=3, moderator=2, member=1
console.log(ROLE_HIERARCHY.admin); // 3
```

### Storage Adapter Interface

```typescript
import type { StorageAdapter, QueryFilter, PaginatedResult } from '@cyber-eco/types';

const adapter: StorageAdapter = {
  async getDocument<T>(collection: string, id: string): Promise<T | null> {
    // Fetch document from Firestore, Supabase, etc.
  },

  async query<T>(
    collection: string,
    filters: QueryFilter[],
    options?: QueryOptions
  ): Promise<PaginatedResult<T>> {
    // Execute filtered query with pagination
  },

  async batchWrite(operations) {
    // Execute multiple writes atomically
  },

  // ... other methods
};
```

### Cache Configuration

```typescript
import type { CacheConfig } from '@cyber-eco/types';
import { DEFAULT_CACHE_TTLS } from '@cyber-eco/types';

const cacheConfig: CacheConfig = {
  l1: { maxEntries: 1000 },
  l2: myRedisBackend,
  strategy: { staleWhileRevalidate: true },
  ttls: {
    users: 5 * 60 * 1000, // 5 minutes
    ...DEFAULT_CACHE_TTLS,
  },
};
```

### Data Layer Service

```typescript
import type { IDataLayerService, QueryFilter } from '@cyber-eco/types';

const dataLayer: IDataLayerService = {
  async get<T>(userId: string, collection: string, id: string) {
    // Permission-checked read
  },

  async create<T>(userId: string, collection: string, data: T) {
    // Permission-checked write
  },

  async query<T>(
    userId: string,
    collection: string,
    filters: QueryFilter[],
    options?: QueryOptions
  ) {
    // Permission-checked query
  },

  // ... other CRUD methods
};
```

### Constants

```typescript
import { COLLECTIONS, BREAKPOINTS } from '@cyber-eco/types';

// Firestore collection names
console.log(COLLECTIONS.USERS); // 'users'
console.log(COLLECTIONS.TRANSACTIONS); // 'transactions'

// Responsive breakpoints
console.log(BREAKPOINTS.tablet); // 768
console.log(BREAKPOINTS.desktop); // 1024
```

### JustSplit Types

```typescript
import { JustSplit } from '@cyber-eco/types';

const expense: JustSplit.Expense = {
  id: 'exp123',
  description: 'Dinner',
  amount: 120.0,
  currency: 'USD',
  date: '2025-01-15',
  paidBy: 'user1',
  participants: ['user1', 'user2', 'user3'],
  settled: false,
  createdAt: '2025-01-15T19:00:00Z',
};

const event: JustSplit.Event = {
  id: 'evt123',
  name: 'Weekend Trip',
  startDate: '2025-02-01',
  createdAt: '2025-01-15',
  createdBy: 'user1',
  members: ['user1', 'user2'],
  expenseIds: ['exp123'],
};
```

## Package Structure

```
src/
├── index.ts                  # Barrel exports
├── user.ts                   # BaseUser, HubUser, SharedUserProfile
├── auth.ts                   # AuthUser, AuthToken
├── app.ts                    # App, AppConfig
├── permissions.ts            # AppPermission, ResourcePermission (4-tier)
├── groups.ts                 # SharedGroup, GroupMember (4-tier), UserRelationship
├── friendship.ts             # Friendship (promoted from JustSplit)
├── financial.ts              # Transaction, Budget, BankAccount, FinancialSummary
├── activity.ts               # SharedActivity, ActivitySummary
├── notifications.ts          # Notification
├── navigation.ts             # NavigationLink, NavigationProps, nav configs
├── query.ts                  # QueryFilter, QueryOptions, PaginatedResult
├── storage-adapter.ts        # StorageAdapter interface
├── cache.ts                  # CacheBackend, CacheConfig, DEFAULT_CACHE_TTLS
├── sync.ts                   # SyncEvent, DataSyncStatus, ConflictResolution
├── webhook.ts                # WebhookEvent, WebhookRegistration
├── service.ts                # IDataLayerService, DataLayerConfig
├── constants/
│   ├── breakpoints.ts        # BREAKPOINTS, mediaQuery helpers
│   ├── roles.ts              # ROLE_HIERARCHY, hasMinimumRole
│   └── collections.ts        # COLLECTIONS constant
└── justsplit/
    └── types.ts              # JustSplit namespace types
```

## Key Enhancements from Monorepo

1. **4-tier role hierarchy**: `owner | admin | moderator | member` (was 3-tier)
2. **Theme preference**: `system` instead of `auto`
3. **Merged AppPermission**: Includes `grantedAt`, `grantedBy`, `conditions`
4. **Promoted Friendship**: From JustSplit to shared types
5. **New orchestration interfaces**: StorageAdapter, CacheBackend, IDataLayerService

## Type Safety

All types are fully typed with TypeScript strict mode:

- No `any` types (except in specific metadata fields)
- Const assertions for constants
- Discriminated unions where applicable
- Comprehensive JSDoc comments

## Contributing

This package is part of the CyberEco Hub monorepo. Changes should maintain backward compatibility and zero runtime dependencies.

## License

Apache-2.0 — see the LICENSE file. Part of the CyberEco open-core data layer (packages are Apache-2.0; the platform is proprietary). See root LICENSE.md and ADR-010.
